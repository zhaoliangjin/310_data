facial recognition model
