video analysis model
