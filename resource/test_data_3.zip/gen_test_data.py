#coding=utf-8
'''
版权信息：华为技术有限公司， 版权所有（c） 2010-2019
功能：抽取caffe模型的指定层，及其对应的输出、输出、权重及偏置
创建：2019-1-29 16:50
'''

import caffe
import numpy as NP

def dumpData(inputData, name, fmt, data_type):
    if fmt == "binary" or fmt == "bin":
        fOutput = open(name, "wb")
        if(data_type == "float16"):
            for elem in NP.nditer(inputData, op_flags = ["readonly"]):
                fOutput.write(NP.float16(elem).tobytes())
        elif(data_type == "float32"):
            for elem in NP.nditer(inputData, op_flags = ["readonly"]):
                fOutput.write(NP.float32(elem).tobytes())
        elif(data_type == "int32"):
            for elem in NP.nditer(inputData, op_flags = ["readonly"]):
                fOutput.write(NP.int32(elem).tobytes())
        elif(data_type == "int8"):
            for elem in NP.nditer(inputData, op_flags = ["readonly"]):
                fOutput.write(NP.int8(elem).tobytes())
        elif(data_type == "uint8"):
            for elem in NP.nditer(inputData, op_flags = ["readonly"]):
                fOutput.write(NP.uint8(elem).tobytes())
    else:
        fOutput = open(name, "w")
        index = 0
        for elem in NP.nditer(inputData):
            fOutput.write("%f\t" % elem)
            index += 1
            if index % 16 == 0:
                fOutput.write("\n")


    
def extract_caffe_op(model, weights, extract_layer_name, last_layer_name, img_path, data_input_shape, data_type):
    '''
    抽取caffe模型的指定层，及其对应的输出、输出、权重及偏置

    model: 模型文件
    weights: 权重文件
    extract_layer_name: 被抽取的层名
    last_layer_name:  被抽取层的上一层的层名
    img_path: 测试样本，用于前向推理
    data_input_shape: 网络数据层的输入数据shape
    data_type: 输出数据类型
    '''
    caffe.set_mode_cpu()
    net = caffe.Net(model, weights, caffe.TEST)
    print("blobs {}\nparams {}".format(net.blobs.keys(), net.params.keys()))


    #保存extract layer的参数（如果有参数）
    if(net.params.has_key(extract_layer_name)):
        print("%s params size: %d"%(extract_layer_name, len(net.params[extract_layer_name])))
        for idx in range(len(net.params[extract_layer_name])):
            param_file_name = "./extract_layer_param%d.bin"%(idx)
            print('============params %d================='%(idx))
            print(net.params[extract_layer_name][idx].data)
            print(net.params[extract_layer_name][idx].shape)
            with open(param_file_name, 'wb') as f:
                dumpData(net.params[extract_layer_name][idx].data, extract_layer_name + '_param_' + idx + '.txt', "txt", data_type)
                dumpData(net.params[extract_layer_name][idx].data, extract_layer_name + '_param_' + idx + '.bin', "bin", data_type)

    transform=caffe.io.Transformer({'data':net.blobs['data'].data.shape})
    
    transform.set_transpose('data',(2,0,1))
    transform.set_raw_scale('data',255)
    #transform.set_channel_swap('data',(2,1,0))
    
    #加载图像文件
    image=caffe.io.load_image(img_path, color = False)
    transformed_image=transform.preprocess('data',image)
    
    # 把警告过transform.preprocess处理过的图片加载到内存
    net.blobs['data'].data[...]=transformed_image
    #把加载到的图片缩放到固定的大小
    net.blobs['data'].reshape(*data_input_shape)
    net.forward()

    fea_in=net.blobs[last_layer_name].data   #提取上一层数据（特征）
    print('===========extracted layer input==================')
    print(fea_in)
    print(fea_in.shape)


    fea_out=net.blobs[extract_layer_name].data   #提取当前层数据（特征）
    print('===========extracted layer output==================')
    print(fea_out)
    print(fea_out.shape)
        
    dumpData(fea_in, extract_layer_name+ '_input.txt', "txt", data_type)
    dumpData(fea_in, extract_layer_name+ '_input.data', "bin", data_type)
        
    dumpData(fea_out, extract_layer_name+ '_output.txt', "txt", data_type)
    dumpData(fea_out, extract_layer_name+ '_output.data', "bin", data_type)


if __name__ == "__main__":
    model = './deploy_mylenet-1.prototxt'
    weights = './mylenet-1.caffemodel'
    extract_layer_name = 'reduction'
    last_layer_name = 'prob'
    img_path = './1.jpg'
    data_type = "float16"
    data_input_shape = (1,1,28,28)
    extract_caffe_op(model, weights, extract_layer_name, last_layer_name, img_path, data_input_shape, data_type)
