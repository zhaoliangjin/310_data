/*
Copyright (C) 2018. Huawei Technologies Co., Ltd. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of the Apache License Version 2.0.You may not use this file except in compliance with the License.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
Apache License for more details at
http://www.apache.org/licenses/LICENSE-2.0
*/
#include <Python.h>
#include "omg/register.h" 
#include "proto/caffe/caffe.pb.h" 
#include "omg/parser/caffe/caffe_tvm_op_parser.h" 
#include "omg/model/op_builder/tvm_op_builder.h"  
#include <string> 
#include <iostream> 
namespace domi 
{ 
 
// ####  ReductionParser是解析器的类名，可以随意指定，只要最后注册时使用此类名即可 
class ReductionParser : public CaffeTVMOpParser 
{ 
public: 
    ReductionParser() 
    { 
    } 
 
    ~ReductionParser(){}; 
 
    virtual Status ParseParams(const Message* op_src, OpDef*  op_dest) override 
    { 
        const caffe::LayerParameter* layer = 
            dynamic_cast<const caffe::LayerParameter*>(op_src); 
 
        //#### 输入算子参数合法性校验 
        if (nullptr == layer) 
        { 
            printf("Dynamic cast op_src to LayerParameter failed\n"); 
            return FAILED; 
        } 
        // #### 算子操作类型与其字符串对应的MAP 
        std::map<::caffe::ReductionParameter_ReductionOp, std::string> operation_map = { 
            { caffe::ReductionParameter_ReductionOp_SUM, "SUM" }, 
        { caffe::ReductionParameter_ReductionOp_ASUM, "ASUM" }, 
        { caffe::ReductionParameter_ReductionOp_SUMSQ, "SUMSQ" }, 
        { caffe::ReductionParameter_ReductionOp_MEAN, "MEAN" }, 
        }; 
        // #### 获取算子参数 
        const ::caffe::ReductionParameter& param = layer->reduction_param(); 
 
        //#### 设置参数至op_dest中 
        AddOpAttr("operation", operation_map[param.operation()], op_dest); 
        AddOpAttr("axis", (int32_t)param.axis(), op_dest); 
        AddOpAttr("coeff", param.coeff(), op_dest); 
        return SUCCESS; 
    } 
 
    virtual Status ParseWeights(const Message* op_src, OpDef* op_dest) override 
    { 
        return SUCCESS; 
    } 
}; 
 
// #### ReductionBuilder是构建器的类名，可以随意指定，只要最后注册时使用此类名即可 
class ReductionBuilder : public TVMOpBuilder 
{ 
public: 
    using TVMOpBuilder::TVMOpBuilder; 
 
    ~ReductionBuilder() 
    { 
    } 
    // #### 获取输出tensor描述的处理函数 
    virtual Status GetOutputDesc(vector<TensorDescriptor>& v_output_desc) override 
    { 
        v_output_desc.push_back(op_def_->input_desc(0)); 
 
        int32_t axis = -1; 
        // #### 解析axis参数 
        if (!GetOpAttr("axis", &axis, op_def_)) 
        { 
            printf("GetOpAttr axis failed!\n"); 
        } 
        // #### 由于davinci模型会将所有shape补齐到4d，这里需要修复axis，指向原来2d时的位置 
        if (axis < 0) axis -= 2; 
 
        if (axis < 0) axis += v_output_desc[0].dim_size(); 
 
        if (axis < 0 || axis >= v_output_desc[0].dim_size()) 
        { 
            printf("invalid axis:%d, dim_size:%d\n", axis, v_output_desc[0].dim_size()); 
            return PARAM_INVALID; 
        } 
        v_output_desc[0].set_dim(axis, 1); 
 
        return SUCCESS; 
    } 
    virtual Status BuildTvmBinFile(TVMBinInfo& tvm_bin_info) override 
    { 
        // 1. call tvm python api to build bin files 
        // 2. set path to TVMBinInfo tvm_bin_info 
        PyObject *pModule = NULL; 
        PyObject *pFunc = NULL; 
        PyObject *pArg = NULL; 
        PyObject *result = NULL; 
 
        // #### python初始化 
        Py_Initialize(); 
 
        // #### 导入topi.cce模块 
        PyRun_SimpleString("import sys"); 
        PyRun_SimpleString("sys.path.append('/projects/ReductionOP_Demo/Reduction/operator')"); 
        pModule = PyImport_ImportModule("Reduction"); 
        if (!pModule) 
        { 
            PyErr_Print(); 
            printf("import topi.cce failed!\n"); 
            return FAILED; 
        } 
        std::string operation; 
        int32_t axis = -1; 
        float coeff = 1; 
        // #### 解析operation参数 
        if (!GetOpAttr("operation", &operation, op_def_)) 
        { 
            // #### 增加异常处理、可维护信息 
            printf("GetOpAttr operation failed!\n"); 
        } 
        // #### 解析axis参数 
        if (!GetOpAttr("axis", &axis, op_def_)) 
        { 
            printf("GetOpAttr axis failed!\n"); 
        } 
        // #### 由于davinci模型会将所有shape补齐到4d，这里需要修复axis，指向原来2d时的位置 
        if (axis < 0) axis -= 2; 
 
        // #### 解析coeff参数 
        if (!GetOpAttr("coeff", &coeff, op_def_)) 
        { 
            printf("GetOpAttr coeff failed!\n"); 
        } 
        // #### 解析输入tensor描述 
        TensorDescriptor input_desc = op_def_->input_desc(0); 
 
        // #### 解析输入shape值，校验其大小是否为4 
        if (input_desc.dim_size() != 4) 
        { 
            printf("The shape size is %d, which is not 4!", input_desc.dim_size()); 
            return FAILED; 
        } 
        // #### 调用Python接口生成Tvm算子 
        pFunc = PyObject_GetAttrString(pModule, "Reduction"); 
        pArg = Py_BuildValue( 
            "(i,i,i,i), s, i, s, f, s", 
            input_desc.dim(0), input_desc.dim(1), input_desc.dim(2), input_desc.dim(3),"float16", 
            axis, operation.c_str(), coeff, "cce_reductionLayer_1_10_1_1_float16__3_SUMSQ_1_0"); 
 
        PyEval_CallObject(pFunc, pArg); 
        // #### 结束pathon调用 
        Py_Finalize(); 
        // #### 设置算子文件路径及kernel name 
        tvm_bin_info.bin_file_path = "./kernel_meta/cce_reductionLayer_1_10_1_1_float16__3_SUMSQ_1_0.o"; 
        tvm_bin_info.json_file_path = "./kernel_meta/cce_reductionLayer_1_10_1_1_float16__3_SUMSQ_1_0.json"; 
        return SUCCESS; 
    } 
 
        virtual Status TransWeights(size_t& mem_offset) override 
        { 
                // trans weights and calculate weights memory size 
                return SUCCESS; 
        } 
}; 
DOMI_REGISTER_OP("caffe_reduction_layer2")                          //  test_reduction是算子在davinci模型的类型名，可以随意指定，不可与已有类型名重复，区分大小写 
    .FrameworkType(CAFFE)                                          //  枚举类型，CAFFE, CAFFE2, MXNET, TENSORFLOW 
    .OriginOpType("Reduction")                                     //  Reduction表示该算子在caffe框架中的类型名 
    .ParserCreatorFn(PARSER_FN(ReductionParser))     //  ReductionParser对应上面的类名 
    .BuilderCreatorFn(BUILDER_FN(ReductionBuilder))  //  ReductionBuilder对应上面的类名 
    .ImplyType(ImplyType::TVM);                                    //  实现类型，当前只支持TVM 
 
}  // namespace domi
