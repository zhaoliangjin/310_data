用例使用说明：
(1) 模型转换
进入到model目录， 运行./createmodel.sh文件
(2) 运行路径配置
先编译sample_device.so，放置到hiaiengine目录
(3) 编译sample_demo执行文件，放置到hiaiengine上层目录
执行./sample_demo